/* esm.sh - react@19.0.0/jsx-runtime */
var p=Object.create;var j=Object.defineProperty;var v=Object.getOwnPropertyDescriptor;var a=Object.getOwnPropertyNames;var k=Object.getPrototypeOf,T=Object.prototype.hasOwnProperty;var n=(e,r)=>()=>(r||e((r={exports:{}}).exports,r),r.exports);var f=(e,r,t,o)=>{if(r&&typeof r=="object"||typeof r=="function")for(let s of a(r))!T.call(e,s)&&s!==t&&j(e,s,{get:()=>r[s],enumerable:!(o=v(r,s))||o.enumerable});return e};var m=(e,r,t)=>(t=e!=null?p(k(e)):{},f(r||!e||!e.__esModule?j(t,"default",{value:e,enumerable:!0}):t,e));var E=n(l=>{"use strict";var _=Symbol.for("react.transitional.element"),c=Symbol.for("react.fragment");function x(e,r,t){var o=null;if(t!==void 0&&(o=""+t),r.key!==void 0&&(o=""+r.key),"key"in r){t={};for(var s in r)s!=="key"&&(t[s]=r[s])}else t=r;return r=t.ref,{$$typeof:_,type:e,key:o,ref:r!==void 0?r:null,props:t}}l.Fragment=c;l.jsx=x;l.jsxs=x});var i=n((P,d)=>{"use strict";d.exports=E()});var u=m(i()),{Fragment:R,jsx:q,jsxs:C}=u,M=u.default??u;export{R as Fragment,M as default,q as jsx,C as jsxs};
/*! Bundled license information:

react/cjs/react-jsx-runtime.production.js:
  (**
   * @license React
   * react-jsx-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
//# sourceMappingURL=jsx-runtime.mjs.map